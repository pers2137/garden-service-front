export const environment = {
    port: 8082,
    host: 'localhost'
};
