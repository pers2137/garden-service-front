export interface Station {
    name?: string;
    id?: number;
  }
  