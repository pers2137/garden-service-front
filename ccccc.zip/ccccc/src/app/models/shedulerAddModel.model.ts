/* tslint:disable */
export interface ShedulerAddModel {
    uuid: string;
    pinNumber: number;
    dayNumber: number;
    hourStart: number;
    minuteStart: number;
    hourStop: number;
    minuteStop: number;
  }
  