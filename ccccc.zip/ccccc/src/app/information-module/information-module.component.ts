import { Component } from '@angular/core';

@Component({
  selector: 'app-information-module',
  templateUrl: './information-module.component.html',
  styleUrls: ['./information-module.component.scss']
})
export class InformationModuleComponent {

}
