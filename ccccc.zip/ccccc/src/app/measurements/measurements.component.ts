import { Component, OnInit, EventEmitter } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { StationService } from '../services/station-service.service';
import { ActivatedRoute, ActivatedRouteSnapshot } from '@angular/router';

export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'LL',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

export interface StationList { 
  stationListElement: [{
    id: number;
    name: string;
  }]
};

export interface ChartData { 
  chartDataA: {
    sensorData: [{
      sensorId: string;
      measurementsForSensorList: [{
        value: number;
        timestamp: number;
      }]
    }];
    measurementType: string;
  },
  chartDataB: {
    sensorData: [{
      sensorId: string;
      measurementsForSensorList: [{
        value: number;
        timestamp: number;
      }]
    }];
    measurementType: string;
  }
};


interface SensorsType {
  type: string;
  description: string;
}

@Component({
  selector: 'app-measurements',
  templateUrl: './measurements.component.html',
  styleUrls: ['./measurements.component.scss'],
})
export class MeasurementsComponent implements OnInit {


  sensorsType: SensorsType[] = [
    {type: 'S', description: 'Czujnik nasłonecznienia'},
    {type: 'SH', description: 'Czujnik wilgotnośći gleby'},
    {type: 'DS', description: 'Czujnik ds18b20'},
    {type: 'DHT', description: 'Czujnik temperatury i wilgotności powietrza'},
  ];
  
  parentEmitter = new EventEmitter<[]>(); 

  startDate = new Date();
  endDate = new Date();
  stationList: any = [];
  chartData: ChartData;
  selectedStationId: number;
  typ: string;
  
  sensorsGroup: FormGroup;

  constructor(private formBuilder: FormBuilder, private stationService: StationService) {
    this.sensorsGroup = this.formBuilder.group({
      selectCtrl: [false],
    });
  }

  ngOnInit() {
    this.stationService.getStationsList().subscribe(
      resData => {
        this.stationList = resData.stationListElement;
      },
      errorMessage => {
        console.log(errorMessage);
      });
    }

    test() {
      var sensorTab: any = [];
      for (let i = 0; i < this.chartData.chartDataA.sensorData.length; i++) {
        sensorTab.push(this.sensorsGroup.controls[i].value == true)
      }
      this.parentEmitter.emit(sensorTab); 
    }


  inputChange() {
    this.stationService.getMeasurements(this.selectedStationId, this.typ,  this.startDate, this.endDate).subscribe(
      resData => {
          this.chartData = resData;
          console.log(this.chartData);

          this.chartData.chartDataA.sensorData.forEach(
            sensor => {
              this.formBuilder.group(this.sensorsGroup);
              this.sensorsGroup.addControl(sensor.sensorId, this.formBuilder.control(''))
              this.sensorsGroup.controls[sensor.sensorId].setValue(true);
          }
          )

          
          this.sensorsGroup.updateValueAndValidity();
      },
      errorMessage => {
        console.log(errorMessage);
      }
  );
  }



}
